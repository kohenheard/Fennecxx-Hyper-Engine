# blooket-hack

Hell i'm actually gliz who created the blooket hacks. I got the repo from the guy who was impersonating me. 

**This repo will not be updated at all. If you have any questions join the discord server below I'll be answering them.**

**discord server: https://discord.gg/Nj9Zs5VtFp**

Proof thats it me: ![image](https://user-images.githubusercontent.com/108590774/177013795-80b0e338-fa58-4eba-837f-340bab0c4e9a.png)


# Contact

if you want to contact me just dm me on twitter https://twitter.com/glizuwu
